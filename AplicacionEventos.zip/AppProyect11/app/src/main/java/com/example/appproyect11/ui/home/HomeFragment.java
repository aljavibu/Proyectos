package com.example.appproyect11.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.appproyect11.AdaptadorEventos;
import com.example.appproyect11.Evento;
import com.example.appproyect11.R;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class HomeFragment extends Fragment {
    ArrayList<Evento> listaEventos;
    RecyclerView recyclerEventos;
    SimpleDateFormat sdf= new SimpleDateFormat("dd/MM/yyyy");

    private HomeViewModel homeViewModel;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    private void llenarEventos() throws ParseException {
        Date fecha1 =sdf.parse("28/05/2021");
        Date fecha2 =sdf.parse("18/06/2021");
        Date fecha3 =sdf.parse("10/01/2022");

        listaEventos.add(new Evento("Concierto","Concierto benefico         ",fecha1));
        listaEventos.add(new Evento("Partido","Derbi betis-sevilla             ",fecha2));
        listaEventos.add(new Evento("Maraton","Maraton contra el cancer",fecha3));

    }

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        homeViewModel =
                new ViewModelProvider(this).get(HomeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        return root;
    }



    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view,savedInstanceState);
        listaEventos = new ArrayList<Evento>();
        recyclerEventos = (RecyclerView) view.findViewById(R.id.RecyclerId);
        recyclerEventos.setLayoutManager(new LinearLayoutManager(this.getActivity()));

        try {
            llenarEventos();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        AdaptadorEventos adapter = new AdaptadorEventos(listaEventos);
        recyclerEventos.setAdapter(adapter);
    }
}