package com.example.appproyect11;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class AdaptadorEventos extends RecyclerView.Adapter<AdaptadorEventos.ViewHolderEventos> {
    ArrayList<Evento> listaEventos;

    public AdaptadorEventos(ArrayList<Evento> listaEventos) {
        this.listaEventos = listaEventos;
    }

    @NonNull
    @Override
    public AdaptadorEventos.ViewHolderEventos onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list,null,false);
        return new ViewHolderEventos(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdaptadorEventos.ViewHolderEventos holder, int position) {
        holder.etiNombre.setText(listaEventos.get(position).getNombre());
        holder.etiInformacion.setText(listaEventos.get(position).getInfo());
        holder.etiFecha.setText( listaEventos.get(position).getFecha());
    }

    @Override
    public int getItemCount() {

            return listaEventos.size();


    }

    public class ViewHolderEventos extends RecyclerView.ViewHolder {
        TextView etiNombre,etiInformacion,etiFecha;
        public ViewHolderEventos(@NonNull View itemView) {
            super(itemView);
            etiNombre=(TextView) itemView.findViewById(R.id.idNombre);
            etiInformacion=(TextView) itemView.findViewById(R.id.idInfo);
            etiFecha=(TextView) itemView.findViewById(R.id.idFecha);
        }
    }
}
