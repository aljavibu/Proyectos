package com.example.appproyect11;

import java.text.SimpleDateFormat;
import java.util.Date;

public class Evento {
    private String nombre;
    private String info;
    private Date fecha;
    SimpleDateFormat sdf= new SimpleDateFormat("dd/MM/yyyy");

    public Evento(String nombre, String info, Date fecha) {
        this.nombre = nombre;
        this.info = info;
        this.fecha = fecha;
    }
    public Evento() {

    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getFecha() {
        String fechaCadena=sdf.format(fecha);
        return fechaCadena;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
}
